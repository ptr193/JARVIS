package com.jarvis.pineapple.perception

/**
 * 全息投影接口（功能 #114, #115）。
 *
 * 全息投影需要外接硬件支持，此处为接口预留。
 * AR 界面交互预留 ARCore 集成接口。
 */
interface HolographicProjection {
    /**
     * 初始化全息投影
     */
    fun initialize(): Boolean

    /**
     * 显示全息内容
     */
    fun display(content: HolographicContent): Boolean

    /**
     * 关闭全息投影
     */
    fun shutdown()

    /**
     * 检查硬件是否可用
     */
    fun isHardwareAvailable(): Boolean

    /**
     * 获取投影状态
     */
    fun getStatus(): ProjectionStatus
}

data class HolographicContent(
    val type: ContentType,
    val data: String,
    val position: Position3D? = null,
    val scale: Float = 1.0f
)

enum class ContentType {
    IMAGE, VIDEO, MODEL_3D, TEXT, INTERACTIVE
}

data class Position3D(
    val x: Float,
    val y: Float,
    val z: Float
)

data class ProjectionStatus(
    val isReady: Boolean,
    val isProjecting: Boolean,
    val brightness: Float,
    val errorMessage: String? = null
)

/**
 * AR 界面交互接口（功能 #115）
 */
interface HolographicInterface {
    /**
     * 启动 AR 会话
     */
    fun startSession(): Boolean

    /**
     * 停止 AR 会话
     */
    fun stopSession()

    /**
     * 在 AR 中显示 UI 元素
     */
    fun displayUIElement(element: ARIElement): Boolean

    /**
     * 处理 AR 中的手势
     */
    fun handleGesture(gesture: ARGesture): Boolean
}

data class ARIElement(
    val id: String,
    val type: ARIElementType,
    val content: String,
    val position: Position3D,
    val size: Pair<Float, Float>
)

enum class ARIElementType {
    TEXT, IMAGE, BUTTON, PANEL, VIDEO
}

sealed class ARGesture {
    object Tap : ARGesture()
    data class Swipe(val direction: SwipeDirection) : ARGesture()
    data class Pinch(val scale: Float) : ARGesture()
    object LongPress : ARGesture()
}

enum class SwipeDirection {
    UP, DOWN, LEFT, RIGHT
}

/**
 * 精准抓取接口（功能 #116）
 *
 * 需要外接机械臂支持，此处为接口预留。
 */
interface PrecisionGrasp {
    /**
     * 初始化机械臂
     */
    fun initialize(): Boolean

    /**
     * 定位目标
     */
    fun locateTarget(targetId: String): TargetInfo?

    /**
     * 执行抓取
     */
    fun grasp(targetId: String): Boolean

    /**
     * 释放抓取
     */
    fun release()

    /**
     * 移动机械臂
     */
    fun moveTo(position: Position3D): Boolean
}

data class TargetInfo(
    val targetId: String,
    val position: Position3D,
    val confidence: Float,
    val isGraspable: Boolean
)
