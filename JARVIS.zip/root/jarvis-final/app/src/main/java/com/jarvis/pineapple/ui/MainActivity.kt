package com.jarvis.pineapple.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.jarvis.pineapple.model.ModelScheduler
import com.jarvis.pineapple.speech.SpeechManager
import com.jarvis.pineapple.speech.VoiceWakeManager
import com.jarvis.pineapple.wake.AppIconWakeDetector
import com.jarvis.pineapple.wake.NotificationWakeDetector
import com.jarvis.pineapple.wake.TileWakeDetector
import com.jarvis.pineapple.wake.WakeEngine
import com.jarvis.pineapple.wake.WakeSource
import com.jarvis.pineapple.ui.chat.ChatScreen
import com.jarvis.pineapple.ui.model.ModelSelectionScreen
import com.jarvis.pineapple.ui.settings.SettingsScreen
import com.jarvis.pineapple.ui.theme.JarvisTheme
import com.jarvis.pineapple.ui.vm.VirtualMachineScreen
import com.jarvis.pineapple.ui.voice.VoiceChatScreen
import org.koin.androidx.compose.get

class MainActivity : ComponentActivity() {

    private val iconWakeDetector by lazy { AppIconWakeDetector(this) }
    private val notificationWakeDetector by lazy {
        org.koin.core.context.GlobalContext.get().get<NotificationWakeDetector>()
    }
    private val tileWakeDetector by lazy {
        org.koin.core.context.GlobalContext.get().get<TileWakeDetector>()
    }
    private val wakeEngine by lazy {
        org.koin.core.context.GlobalContext.get().get<WakeEngine>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 注册应用图标快捷方式并处理本次启动的双击/长按唤醒
        iconWakeDetector.start()
        // 启动唤醒引擎（汇总语音/电源键/通知/摇一摇/蓝牙/磁贴/图标/Home 长按 8 种唤醒源）
        wakeEngine.start()
        handleIconWake(intent)
        handleWakeIntent(intent)
        enableEdgeToEdge()
        setContent {
            JarvisTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    JarvisApp()
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIconWake(intent)
        handleWakeIntent(intent)
    }

    /** 处理来自通知唤醒按钮 / 快捷磁贴的 Intent，转为 WakeEngine 唤醒事件。 */
    private fun handleWakeIntent(intent: Intent?) {
        when (intent?.action) {
            NotificationWakeDetector.ACTION_WAKE -> {
                notificationWakeDetector.onWakeAction()
                if (notificationWakeDetector.consume()) {
                    wakeEngine.trigger(WakeSource.NOTIFICATION)
                }
            }
            TileWakeDetector.ACTION_TILE_WAKE -> {
                tileWakeDetector.onTileClick()
                if (tileWakeDetector.consume()) {
                    wakeEngine.trigger(WakeSource.TILE)
                }
            }
        }
    }

    /** 将图标双击/长按转换为 WakeEngine 唤醒事件。 */
    private fun handleIconWake(intent: Intent?) {
        val longPress = intent?.getBooleanExtra(AppIconWakeDetector.EXTRA_LONG_PRESS_WAKE, false) == true
        iconWakeDetector.onIconAction(
            if (longPress) AppIconWakeDetector.ACTION_LONG_PRESS else AppIconWakeDetector.ACTION_TAP
        )
        if (iconWakeDetector.consume()) {
            runCatching {
                org.koin.core.context.GlobalContext.get()
                    .get<WakeEngine>()
                    .trigger(WakeSource.APP_ICON)
            }
        }
    }
}

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Chat : Screen("chat", "对话", Icons.Filled.Chat)
    object Vm : Screen("vm", "虚拟机", Icons.Filled.Terminal)
    object Settings : Screen("settings", "设置", Icons.Filled.Settings)
    // 非底部栏页面（通过 ChatScreen 内部跳转进入）
    object VoiceChat : Screen("voice_chat", "语音对话", Icons.Filled.Mic)
    object ModelSelection : Screen("model_selection", "模型选择", Icons.Filled.Settings)
}

@Composable
fun JarvisApp() {
    val navController = rememberNavController()
    val wakeEngine = get<WakeEngine>()
    LaunchedEffect(Unit) {
        wakeEngine.wakeEvents.collect {
            navController.navigate(Screen.VoiceChat.route) { launchSingleTop = true }
        }
    }
    val modelScheduler = get<ModelScheduler>()
    val availableModels by modelScheduler.availableModels.collectAsState()
    val activeModel by modelScheduler.activeModel.collectAsState()
    val items = listOf(Screen.Chat, Screen.Vm, Screen.Settings)
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Chat.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Chat.route) {
                ChatScreen(onNavigateToVoiceChat = { navController.navigate(Screen.VoiceChat.route) },
                    onNavigateToModelSelection = { navController.navigate(Screen.ModelSelection.route) })
            }
            composable(Screen.Vm.route) {
                VirtualMachineScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Settings.route) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.VoiceChat.route) {
                VoiceChatScreen(
                    onBack = { navController.popBackStack() },
                    speechManager = get<SpeechManager>(),
                    voiceWakeManager = get<VoiceWakeManager>()
                )
            }
            composable(Screen.ModelSelection.route) {
                ModelSelectionScreen(
                    onBack = { navController.popBackStack() },
                    availableModels = availableModels,
                    currentModelId = activeModel.info.id,
                    onModelSelected = { modelScheduler.selectModel(it) }
                )
            }
        }
    }
}
