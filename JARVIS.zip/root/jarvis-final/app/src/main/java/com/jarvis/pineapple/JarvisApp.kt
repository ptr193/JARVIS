package com.jarvis.pineapple

import android.app.Application
import com.jarvis.pineapple.di.appModule
import com.jarvis.pineapple.plugin.PluginManager
import com.jarvis.pineapple.service.KeepAliveService
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin
import org.koin.core.logger.Level

/**
 * JARVIS application entry point.
 */
class JarvisApp : Application() {

    override fun onCreate() {
        super.onCreate()
        instance = this
        startKoin {
            androidLogger(Level.ERROR)
            androidContext(this@JarvisApp)
            modules(appModule)
        }
        // 加载并启用已安装插件（#139）；失败不影响主流程
        runCatching {
            org.koin.core.context.GlobalContext.get().get<PluginManager>().reload()
        }.onFailure {
            android.util.Log.w("JarvisApp", "插件加载失败: ${it.message}")
        }
        KeepAliveService.start(this)
    }

    companion object {
        lateinit var instance: JarvisApp
            private set
    }
}
