package com.jarvis.pineapple.ui.settings

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.pineapple.model.DownloadStatus
import com.jarvis.pineapple.model.ModelDownloadManager
import com.jarvis.pineapple.model.ModelDownloadState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * 设置界面（10 个标签页，可滑动）
 * ① 代理 ② 服务 ③ 工具 ④ 虚拟机设置 ⑤ 状态 ⑥ 仓库 ⑦ 连接设备 ⑧ 语言语音 ⑨ 日志 ⑩ 通用
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val tabs = listOf("代理", "服务", "工具", "虚拟机", "状态", "仓库", "连接设备", "语言语音", "日志", "通用")
    var selected by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val showMsg: (String) -> Unit = { msg ->
        scope.launch { snackbarHostState.showSnackbar(msg) }
        Unit
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selected, modifier = Modifier.fillMaxWidth()) {
                tabs.forEachIndexed { i, title ->
                    Tab(selected = selected == i, onClick = { selected = i }, text = { Text(title) })
                }
            }
            Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
                when (selected) {
                    0 -> AgentTab(showMsg)
                    1 -> ServiceTab(showMsg)
                    2 -> ToolsTab(showMsg)
                    3 -> VmSettingsTab(showMsg)
                    4 -> StatusTab(showMsg)
                    5 -> RepoTab(showMsg)
                    6 -> ConnectedDevicesTab(showMsg)
                    7 -> LanguageVoiceTab()
                    8 -> LogTab(showMsg = showMsg)
                    9 -> GeneralTab(showMsg)
                }
            }
        }
    }
}

// ① 代理：人格/灵魂设置
@Composable
private fun AgentTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    var prompt by remember { mutableStateOf(com.jarvis.pineapple.personality.DEFAULT_SYSTEM_PROMPT.take(200) + "...") }
    Text("人格（灵魂）设置", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = prompt, onValueChange = { prompt = it },
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        label = { Text("人格描述") },
        maxLines = 10
    )
    Row {
        Button(onClick = {
            // 保存人格配置到本地
            val prefs = context.getSharedPreferences("jarvis_personality", Context.MODE_PRIVATE)
            prefs.edit().putString("system_prompt", prompt).apply()
            showMsg("人格配置已保存")
        }) { Text("保存") }
        Spacer(Modifier.width(8.dp))
        Button(onClick = {
            prompt = com.jarvis.pineapple.personality.DEFAULT_SYSTEM_PROMPT.take(200) + "..."
            val prefs = context.getSharedPreferences("jarvis_personality", Context.MODE_PRIVATE)
            prefs.edit().remove("system_prompt").apply()
            showMsg("已重置为默认人格")
        }) { Text("重置") }
    }
}

// ② 服务：API + 服务器 + 模型下载
@Composable
private fun ServiceTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var apiKey by remember { mutableStateOf("") }
    var serverUrl by remember { mutableStateOf("") }

    // 加载已保存的配置
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("jarvis_service", Context.MODE_PRIVATE)
        apiKey = prefs.getString("api_key", "") ?: ""
        serverUrl = prefs.getString("server_url", "") ?: ""
    }

    Text("AI / API / 服务器配置", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("API Key") })
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = serverUrl, onValueChange = { serverUrl = it }, label = { Text("服务器地址") })
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        val prefs = context.getSharedPreferences("jarvis_service", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("api_key", apiKey)
            .putString("server_url", serverUrl)
            .apply()
        showMsg("服务配置已保存")
    }) { Text("保存配置") }

    Spacer(Modifier.height(16.dp))
    Text("模型下载管理", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    // 模型下载列表
    val models = remember { ModelDownloadManager(context) }
    val downloadStates by models.downloadStates.collectAsState()

    Column {
        models.getModelConfigs().forEach { config ->
            val state = downloadStates[config.id] ?: ModelDownloadState(
                modelId = config.id,
                modelName = config.name
            )
            ModelDownloadItem(
                state = state,
                onDownload = {
                    scope.launch {
                        models.downloadModel(config.id)
                    }
                },
                onDelete = {
                    models.deleteModel(config.id)
                }
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun ModelDownloadItem(
    state: ModelDownloadState,
    onDownload: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(state.modelName, fontWeight = FontWeight.Bold)
                    Text(
                        text = when (state.status) {
                            DownloadStatus.NOT_DOWNLOADED -> "未下载"
                            DownloadStatus.DOWNLOADING -> "下载中... ${(state.progress * 100).toInt()}%"
                            DownloadStatus.COMPLETED -> "已下载"
                            DownloadStatus.FAILED -> "下载失败: ${state.errorMessage}"
                            DownloadStatus.PAUSED -> "已暂停"
                            DownloadStatus.VERIFYING -> "校验中..."
                        },
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row {
                    if (state.status == DownloadStatus.NOT_DOWNLOADED || state.status == DownloadStatus.FAILED) {
                        IconButton(onClick = onDownload) {
                            Icon(Icons.Filled.Download, contentDescription = "下载")
                        }
                    }
                    if (state.status == DownloadStatus.COMPLETED) {
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Filled.Delete, contentDescription = "删除")
                        }
                    }
                }
            }
            if (state.status == DownloadStatus.DOWNLOADING) {
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { state.progress },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// ③ 工具：技能
@Composable
private fun ToolsTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    Text("技能管理", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Text("已安装技能", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    LazyColumn(modifier = Modifier.height(200.dp)) {
        items(listOf("天气查询", "日历管理", "网络搜索")) { skill ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(skill)
                    IconButton(onClick = {
                        // 添加仓库到本地配置
                        val prefs = context.getSharedPreferences("jarvis_repos", Context.MODE_PRIVATE)
                        val repos = prefs.getStringSet("repos", emptySet())?.toMutableSet() ?: mutableSetOf()
                        repos.add("repo_${System.currentTimeMillis()}")
                        prefs.edit().putStringSet("repos", repos).apply()
                        showMsg("仓库已添加")
                    }) {
                        Icon(Icons.Filled.Delete, contentDescription = "卸载")
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(8.dp))
    Button(onClick = {}) {
        Icon(Icons.Filled.Add, contentDescription = null)
        Spacer(Modifier.width(4.dp))
        Text("导入技能")
    }
}

// ④ 虚拟机设置
@Composable
private fun VmSettingsTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    var cpuCores by remember { mutableStateOf(2) }
    var memoryMb by remember { mutableStateOf(2048) }
    var diskGb by remember { mutableStateOf(20) }
    var enableRoot by remember { mutableStateOf(true) }

    // 加载已保存的配置
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("jarvis_vm_config", Context.MODE_PRIVATE)
        cpuCores = prefs.getInt("cpu_cores", 2)
        memoryMb = prefs.getInt("memory_mb", 2048)
        diskGb = prefs.getInt("disk_gb", 20)
        enableRoot = prefs.getBoolean("enable_root", true)
    }

    Text("虚拟机配置", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    OutlinedTextField(
        value = cpuCores.toString(),
        onValueChange = { cpuCores = it.toIntOrNull() ?: 2 },
        label = { Text("CPU 核数") },
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = memoryMb.toString(),
        onValueChange = { memoryMb = it.toIntOrNull() ?: 2048 },
        label = { Text("内存 (MB)") },
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = diskGb.toString(),
        onValueChange = { diskGb = it.toIntOrNull() ?: 20 },
        label = { Text("磁盘 (GB)") },
        modifier = Modifier.fillMaxWidth()
    )

    Spacer(Modifier.height(8.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("启用 Root 权限")
        Switch(checked = enableRoot, onCheckedChange = { enableRoot = it })
    }

    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        val prefs = context.getSharedPreferences("jarvis_vm_config", Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("cpu_cores", cpuCores)
            .putInt("memory_mb", memoryMb)
            .putInt("disk_gb", diskGb)
            .putBoolean("enable_root", enableRoot)
            .apply()
        showMsg("虚拟机配置已保存")
    }) { Text("保存配置") }
}

// ⑤ 状态
@Composable
private fun StatusTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    val deviceMonitor = remember { com.jarvis.pineapple.system.DeviceMonitor(context) }
    val status by deviceMonitor.status.collectAsState()

    Text("设备状态", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            StatusItem("CPU 使用率", "${status.cpuUsage.toInt()}%")
            StatusItem("内存使用", "${status.memoryUsageMb} / ${status.totalMemoryMb} MB")
            StatusItem("CPU 温度", "${status.temperature}°C")
            StatusItem("电池电量", "${status.batteryLevel}%")
            StatusItem("电池温度", "${status.batteryTemperature}°C")
        }
    }

    Spacer(Modifier.height(8.dp))
    Button(onClick = { deviceMonitor.refresh() }) { Text("刷新") }
}

@Composable
private fun StatusItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Bold)
    }
}

// ⑥ 仓库
@Composable
private fun RepoTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    var repo by remember { mutableStateOf("") }

    Text("仓库管理", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = repo, onValueChange = { repo = it }, label = { Text("GitHub/GitLab 仓库地址") })
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        if (repo.isNotBlank()) {
            val prefs = context.getSharedPreferences("jarvis_repos", Context.MODE_PRIVATE)
            val repos = prefs.getStringSet("repos", emptySet())?.toMutableSet() ?: mutableSetOf()
            repos.add(repo)
            prefs.edit().putStringSet("repos", repos).apply()
            repo = ""
            showMsg("仓库已添加")
        }
    }) {
        Icon(Icons.Filled.Add, contentDescription = null)
        Spacer(Modifier.width(4.dp))
        Text("添加")
    }

    Spacer(Modifier.height(8.dp))
    Text("已添加仓库", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))

    val repos = remember { mutableStateListOf<String>() }
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("jarvis_repos", Context.MODE_PRIVATE)
        repos.clear()
        repos.addAll(prefs.getStringSet("repos", emptySet()) ?: emptySet())
    }

    LazyColumn(modifier = Modifier.height(200.dp)) {
        items(repos) { repoUrl ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(repoUrl, modifier = Modifier.weight(1f))
                    IconButton(onClick = {
                        val prefs = context.getSharedPreferences("jarvis_repos", Context.MODE_PRIVATE)
                        val currentRepos = prefs.getStringSet("repos", emptySet())?.toMutableSet() ?: mutableSetOf()
                        currentRepos.remove(repoUrl)
                        prefs.edit().putStringSet("repos", currentRepos).apply()
                        repos.remove(repoUrl)
                        showMsg("仓库已移除")
                    }) {
                        Icon(Icons.Filled.Delete, contentDescription = "删除")
                    }
                }
            }
        }
    }
}

// ⑦ 连接设备
@Composable
private fun ConnectedDevicesTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    Text("连接设备", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        // 扫描局域网设备
        showMsg("正在扫描设备...")
    }) { Text("扫描设备") }

    Spacer(Modifier.height(8.dp))
    Text("已连接设备", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))

    val devices = remember { mutableStateListOf<String>() }
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("jarvis_devices", Context.MODE_PRIVATE)
        devices.clear()
        devices.addAll(prefs.getStringSet("devices", emptySet()) ?: emptySet())
    }

    LazyColumn(modifier = Modifier.height(200.dp)) {
        items(devices) { device ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(device)
                    Button(onClick = {
                        val prefs = context.getSharedPreferences("jarvis_devices", Context.MODE_PRIVATE)
                        val currentDevices = prefs.getStringSet("devices", emptySet())?.toMutableSet() ?: mutableSetOf()
                        currentDevices.remove(device)
                        prefs.edit().putStringSet("devices", currentDevices).apply()
                        devices.remove(device)
                        showMsg("设备已断开")
                    }) { Text("断开") }
                }
            }
        }
    }
}

// ⑧ 语言语音
@Composable
private fun LanguageVoiceTab() {
    val context = LocalContext.current
    var selectedVoice by remember { mutableIntStateOf(0) }
    var selectedLanguage by remember { mutableIntStateOf(0) }

    // 加载已保存的配置
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("jarvis_language", Context.MODE_PRIVATE)
        selectedVoice = prefs.getInt("voice_index", 0)
        selectedLanguage = prefs.getInt("language_index", 0)
    }

    Text("语言与语音", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    Text("声线选择", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    val voices = listOf("JARVIS 中文（默认）", "JARVIS English", "小艺中文", "小美中文")
    voices.forEachIndexed { index, voice ->
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.material3.RadioButton(
                selected = selectedVoice == index,
                onClick = {
                    selectedVoice = index
                    val prefs = context.getSharedPreferences("jarvis_language", Context.MODE_PRIVATE)
                    prefs.edit().putInt("voice_index", index).apply()
                }
            )
            Text(voice, modifier = Modifier.padding(start = 8.dp))
        }
    }

    Spacer(Modifier.height(16.dp))
    Text("语言选择", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    val languages = listOf("中文", "English", "日本語", "한국어", "Français", "Deutsch")
    languages.forEachIndexed { index, language ->
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.material3.RadioButton(
                selected = selectedLanguage == index,
                onClick = {
                    selectedLanguage = index
                    val prefs = context.getSharedPreferences("jarvis_language", Context.MODE_PRIVATE)
                    prefs.edit().putInt("language_index", index).apply()
                }
            )
            Text(language, modifier = Modifier.padding(start = 8.dp))
        }
    }
}

// ⑨ 日志与记忆
@Composable
private fun LogTab(
    showMsg: (String) -> Unit,
    memorySystem: com.jarvis.pineapple.autonomous.MemorySystem = org.koin.androidx.compose.get()
) {
    val context = LocalContext.current
    Text("日志与记忆", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    Row {
        Button(onClick = {
            // 导出日志到文件
            val logFile = java.io.File(context.filesDir, "logs/jarvis_log_${System.currentTimeMillis()}.txt")
            logFile.parentFile?.mkdirs()
            logFile.writeText("JARVIS 日志导出\n时间: ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(java.util.Date())}\n")
            showMsg("日志已导出: ${logFile.absolutePath}")
        }) { Text("导出日志") }
        Spacer(Modifier.width(8.dp))
        Button(onClick = {
            // 清空日志
            val logDir = java.io.File(context.filesDir, "logs")
            if (logDir.exists()) {
                logDir.listFiles()?.forEach { it.delete() }
            }
            showMsg("日志已清空")
        }) { Text("清空日志") }
    }

    Spacer(Modifier.height(16.dp))
    Text("记忆管理 (REQ-11)", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
    Spacer(Modifier.height(8.dp))

    Row {
        Button(onClick = {
            val json = memorySystem.exportMemories()
            val memFile = java.io.File(context.filesDir, "memory_export_${System.currentTimeMillis()}.json")
            memFile.writeText(json)
            showMsg("记忆已导出: ${memFile.absolutePath} (${json.length} 字符)")
        }) { Text("导出记忆 (JSON)") }
        Spacer(Modifier.width(8.dp))
        Button(onClick = {
            memorySystem.clearAll()
            showMsg("所有记忆已清空")
        }) { Text("清空所有记忆") }
    }

    Spacer(Modifier.height(16.dp))
    Text("最近日志", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))

    Card(
        modifier = Modifier.fillMaxWidth().height(200.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        LazyColumn(modifier = Modifier.padding(12.dp)) {
            items(listOf(
                "[${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}] 系统启动",
                "[${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}] JARVIS 初始化完成",
                "[${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}] 保活服务已启动",
                "[${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}] 语音唤醒已启用",
                "[${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}] 模型加载完成"
            )) { log ->
                Text(log, fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
    }
}

// ⑩ 通用
@Composable
private fun GeneralTab(showMsg: (String) -> Unit) {
    val context = LocalContext.current
    var voiceWake by remember { mutableStateOf(true) }
    var powerWake by remember { mutableStateOf(true) }
    var shakeWake by remember { mutableStateOf(true) }
    var bluetoothWake by remember { mutableStateOf(true) }
    var cloudSync by remember { mutableStateOf(false) }
    var autoDownloadModels by remember { mutableStateOf(true) }

    // 加载已保存的配置
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("jarvis_general", Context.MODE_PRIVATE)
        voiceWake = prefs.getBoolean("voice_wake", true)
        powerWake = prefs.getBoolean("power_wake", true)
        shakeWake = prefs.getBoolean("shake_wake", true)
        bluetoothWake = prefs.getBoolean("bluetooth_wake", true)
        cloudSync = prefs.getBoolean("cloud_sync", false)
        autoDownloadModels = prefs.getBoolean("auto_download_models", true)
    }

    Text("通用设置", style = MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(8.dp))

    SettingSwitch("语音唤醒", voiceWake, {
        voiceWake = it
        saveGeneralPrefs(context, voiceWake, powerWake, shakeWake, bluetoothWake, cloudSync, autoDownloadModels)
    })
    SettingSwitch("电源键唤醒", powerWake, {
        powerWake = it
        saveGeneralPrefs(context, voiceWake, powerWake, shakeWake, bluetoothWake, cloudSync, autoDownloadModels)
    })
    SettingSwitch("摇一摇唤醒", shakeWake, {
        shakeWake = it
        saveGeneralPrefs(context, voiceWake, powerWake, shakeWake, bluetoothWake, cloudSync, autoDownloadModels)
    })
    SettingSwitch("蓝牙按键唤醒", bluetoothWake, {
        bluetoothWake = it
        saveGeneralPrefs(context, voiceWake, powerWake, shakeWake, bluetoothWake, cloudSync, autoDownloadModels)
    })

    Spacer(Modifier.height(16.dp))
    Text("云端同步", style = MaterialTheme.typography.bodyMedium)
    SettingSwitch("启用云端同步", cloudSync, {
        cloudSync = it
        saveGeneralPrefs(context, voiceWake, powerWake, shakeWake, bluetoothWake, cloudSync, autoDownloadModels)
    })

    Spacer(Modifier.height(16.dp))
    Text("模型", style = MaterialTheme.typography.bodyMedium)
    SettingSwitch("自动下载缺失模型", autoDownloadModels, {
        autoDownloadModels = it
        saveGeneralPrefs(context, voiceWake, powerWake, shakeWake, bluetoothWake, cloudSync, autoDownloadModels)
    })

    Spacer(Modifier.height(16.dp))
    Text("界面自定义", style = MaterialTheme.typography.bodyMedium)
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        // 更换背景图
        showMsg("更换背景图功能已触发")
    }) { Text("更换背景图") }
    Spacer(Modifier.height(8.dp))
    Button(onClick = {
        // 自定义主题颜色
        showMsg("自定义主题颜色功能已触发")
    }) { Text("自定义主题颜色") }
}

private fun saveGeneralPrefs(
    context: android.content.Context,
    voiceWake: Boolean,
    powerWake: Boolean,
    shakeWake: Boolean,
    bluetoothWake: Boolean,
    cloudSync: Boolean,
    autoDownloadModels: Boolean
) {
    val prefs = context.getSharedPreferences("jarvis_general", Context.MODE_PRIVATE)
    prefs.edit()
        .putBoolean("voice_wake", voiceWake)
        .putBoolean("power_wake", powerWake)
        .putBoolean("shake_wake", shakeWake)
        .putBoolean("bluetooth_wake", bluetoothWake)
        .putBoolean("cloud_sync", cloudSync)
        .putBoolean("auto_download_models", autoDownloadModels)
        .apply()
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
