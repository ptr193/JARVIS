package com.jarvis.pineapple.chat

import com.jarvis.pineapple.autonomous.MemorySystem
import com.jarvis.pineapple.model.AiModel
import com.jarvis.pineapple.model.ModelCapabilityScheduler
import com.jarvis.pineapple.model.ModelScheduler
import com.jarvis.pineapple.personality.PersonalityRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onEach

/**
 * 对话引擎。
 * - 多轮对话上下文管理
 * - 消息发送与接收
 * - 流式回复
 * - 对话历史持久化
 * - 人格 prompt 注入
 * - 记忆系统上下文注入（REQ-11）
 * - 模型能力短板自动调度（REQ-13）
 */
class ChatEngine(
    private val modelScheduler: ModelScheduler,
    private val personalityRepository: PersonalityRepository,
    private val conversationRepository: ConversationRepository,
    private val memorySystem: MemorySystem,
    private val capabilityScheduler: ModelCapabilityScheduler
) {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _lastSchedulingInfo = MutableStateFlow<String?>(null)
    val lastSchedulingInfo: StateFlow<String?> = _lastSchedulingInfo.asStateFlow()

    private var conversation = Conversation()

    init {
        val recentConversation = conversationRepository.getCurrentConversation()
        if (recentConversation != null) {
            conversation = recentConversation
            _messages.value = recentConversation.messages.toList()
        }
    }

    suspend fun sendUserMessage(content: String): Flow<String> {
        val userMsg = ChatMessage(role = Role.USER, content = content)
        conversation.messages.add(userMsg)
        _messages.value = conversation.messages.toList()

        _isGenerating.value = true

        val primaryModel: AiModel = modelScheduler.getActive()
        val personality = personalityRepository.personality.first()
        val systemPrompt = personalityRepository.buildSystemPrompt(personality)

        val decision = capabilityScheduler.analyzeAndDecide(content)
        _lastSchedulingInfo.value = decision.reason

        val context = buildContextPrompt()
        val memoryContext = memorySystem.buildMemoryContext(content)

        val fullPrompt = buildString {
            if (memoryContext.isNotEmpty()) {
                append(memoryContext)
                appendLine()
            }
            append(context)
            append("\n用户：").append(content)
            append("\nJARVIS：")
        }

        val aiMsg = ChatMessage(role = Role.ASSISTANT, content = "", isStreaming = true)
        conversation.messages.add(aiMsg)
        _messages.value = conversation.messages.toList()

        val activeModel = if (decision.shouldSchedule && decision.assistantModel != null) {
            decision.assistantModel
        } else {
            primaryModel
        }

        val flow = activeModel.stream(fullPrompt, systemPrompt)
        val collected = StringBuilder()

        return flow
            .onEach { chunk ->
                collected.append(chunk)
                val idx = conversation.messages.indexOfLast { it.isStreaming }
                if (idx >= 0) {
                    conversation.messages[idx] = conversation.messages[idx].copy(content = collected.toString())
                    _messages.value = conversation.messages.toList()
                }
            }
            .onCompletion {
                val idx = conversation.messages.indexOfLast { it.isStreaming }
                if (idx >= 0) {
                    conversation.messages[idx] = conversation.messages[idx].copy(isStreaming = false)
                    _messages.value = conversation.messages.toList()
                }
                _isGenerating.value = false

                conversationRepository.updateMessages(conversation.messages.toList())

                if (collected.isNotEmpty()) {
                    val summary = "用户问：${content.take(50)}... JARVIS答：${collected.toString().take(100)}..."
                    memorySystem.recordConversation(summary)
                }
            }
    }

    fun newConversation(title: String = "新对话") {
        conversation = conversationRepository.createConversation(title)
        _messages.value = emptyList()
        _lastSchedulingInfo.value = null
    }

    fun switchConversation(conversationId: String) {
        conversationRepository.switchConversation(conversationId)
        val conv = conversationRepository.getCurrentConversation()
        if (conv != null) {
            conversation = conv
            _messages.value = conv.messages.toList()
        }
    }

    private fun buildContextPrompt(): String {
        val recent = conversation.messages.takeLast(20)
        return recent.joinToString("\n") { msg ->
            when (msg.role) {
                Role.USER -> "用户：${msg.content}"
                Role.ASSISTANT -> "JARVIS：${msg.content}"
                Role.SYSTEM -> ""
            }
        }
    }

    fun clearConversation() {
        conversation.messages.clear()
        _messages.value = emptyList()
        conversationRepository.updateMessages(emptyList())
    }
}
